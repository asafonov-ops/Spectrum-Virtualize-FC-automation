# Enhanced interface
# Functions in this module generate most HTML pages for the portal
# Some other HTML pages a generated with the templates from the template directory

from flask import url_for, request, render_template, redirect
from app import app, my_tenant, my_portal
from global_settings import *
import storage_account
import credentials
import bucket
import json


@app.route('/')
def home():
    my_portal.init(url_for('home'), url_for('account_admin'), url_for('tenant_actions'), url_for('about'))
    account_admin_link = '<p><a href="{}">Account Admin</a><br>(Create/delete/modify storage accounts)</p>'\
        .format(my_portal.url_for_account_admin)
    tenant_actions_link = '<p><a href="{}">Tenant Actions</a><br>(Administer access keys and buckets)</p>'\
        .format(my_portal.url_for_tenant_actions)
    quick_login_link = '<p><a href="{}">Quick Login</a><br>for {}, access key: {}</p>'\
        .format(url_for('quick_login'), QUICK_LOGIN_STORAGE_ACCOUNT, QUICK_LOGIN_ACCESS_KEY_ID)
    about_link = '<a href="{}">About...</a>'\
        .format(my_portal.url_for_about)
    
    lines = my_portal.html_start("Main Menu") + account_admin_link + tenant_actions_link
    if QUICK_LOGIN_ENABLED:
        lines += quick_login_link
    lines += '<div style="border-top: 1px solid silver;padding-top: 5px;">{}</div>'.format(about_link) \
             + my_portal.html_end()
    return lines


@app.route('/account_admin')
def account_admin():
    my_portal.set_active_navbar_item('account_admin')
    account_list_link = '<a href="' + url_for('account_list') + '">List</a>'
    account_create_link = '<a href="' + url_for('account_create') + '">Create</a>'
    account_delete_link = '<a href="' + url_for('account_delete') + '">Delete</a>'
    account_modify_link = '<a href="' + url_for('account_modify') + '">Modify</a>'
    account_list_containers_link = '<a href="' + url_for('account_list_containers') + '">List buckets</a>'
    account_retrieval_link = '<a href="' + url_for('account_retrieval') + '">Account retrieval</a>'
    specific_account_listing_link = '<a href="' + url_for('specific_account_listing') + '">Specific account listing</a>'
    return my_portal.html_start("Storage Account Management") + """
                    <div> """ + account_list_link + """ all Storage Accounts</div>
                    <div> """ + account_create_link + """ a new Storage Account</div>
                    <div> """ + account_delete_link + """ a Storage Account</div>
                    <div> """ + account_modify_link + """ a Storage Account</div>
                    <div> """ + account_list_containers_link + """ for a specific Storage Account</div>
                    <div> """ + account_retrieval_link + """ (account metadata listing)</div>
                    <div> """ + specific_account_listing_link + """ (storage usage for a Storage Account)</div>
                    <div><br><br> Note: Tenant = Storage Account = Account <br></div>""" \
                    + my_portal.html_end()


@app.route('/tenant_actions')
def tenant_actions():
    if not my_tenant.get_login_status():   # if tenant is not logged in, redirect to the login page
        return redirect(url_for('tenant_login'))
    my_portal.set_active_navbar_item('tenant_actions')
    credentials_list_link = '<a href="' + url_for('credentials_list') + '">List credentials</a>'
    credential_create_link = '<a href="' + url_for('credential_create') + '">Create new credential</a>'
    credential_delete_link = '<a href="' + url_for('credential_delete') + '">Delete credential</a>'
    credential_show_details_link = '<a href="' + url_for('credential_show_details') + '">Show credential details</a>'
    update_credential_details_link = '<a href="' + url_for('update_credential_details') + '">Update credential</a>'
    select_credential_link = '<a href="' + url_for('select_credential') + '">Select credential</a>'
    if my_tenant.get_active_credential() != "":
        create_bucket_link = '<a href="' + url_for('create_bucket') + '">Create bucket</a>'
        delete_bucket_link = '<a href="' + url_for('delete_bucket') + '">Delete bucket</a>'
        list_buckets_link = '<a href="' + url_for('list_buckets') + '">List buckets</a>'
        get_bucket_acl_link = '<a href="' + url_for('get_bucket_acl') + '">Get bucket ACL</a>'
        put_bucket_canned_acl_link = '<a href="' + url_for('put_bucket_canned_acl') + '">Put bucket canned ACL</a>'
        put_bucket_acl_link = '<a href="' + url_for('put_bucket_acl') + '">Put bucket ACL</a>'
    else:   # if there is no active credential selected, we force selection (credentials are needed for bucket ops)
        select_first = ' <a href="' + url_for('select_credential') + '">>>> Select credential first</a>'
        create_bucket_link = 'Create bucket' + select_first
        delete_bucket_link = 'Delete bucket' + select_first
        list_buckets_link = 'List buckets' + select_first
        get_bucket_acl_link = 'Get bucket ACL' + select_first
        put_bucket_canned_acl_link = 'Put bucket canned ACL' + select_first
        put_bucket_acl_link = 'Put bucket ACL' + select_first
    tenant_logout_link = '<a href="' + url_for('tenant_logout') + '">(Logout)</a>'
    return \
        my_portal.html_start("Tenant Actions") + \
        '<div>Logged in as: <span style="color:royalblue">' + my_tenant.get_username() + '</span> ' \
        '<font size="1">' + tenant_logout_link + '</font></div><br>' + \
        '<div> ' + credential_create_link + """ (Access Key ID/Secret Access Key pair)</div>
        <div> """ + credential_delete_link + """</div>
        <div> """ + credentials_list_link + """</div>
        <div> """ + credential_show_details_link + """</div>
        <div> """ + update_credential_details_link + """ (change secret access key, status)</div>
        <p></p>
        <div> """ + select_credential_link + """ for bucket operations (current: 
        <span style="color:royalblue">""" + my_tenant.get_active_credential() + """</span>) </div>
        <p></p>
        <div> """ + create_bucket_link + """</div>
        <div> """ + delete_bucket_link + """</div>
        <div> """ + list_buckets_link + """</div>
        <div> """ + get_bucket_acl_link + """</div>
        <div> """ + put_bucket_acl_link + """</div>
        <div> """ + put_bucket_canned_acl_link + """</div>
        <p></p>
        <div> Note: bucket = container </div>""" + \
        my_portal.html_end()


@app.route('/about')
def about():
    my_portal.set_active_navbar_item('about')
    return my_portal.html_start(PORTAL_NAME) + \
        """Simple portal to demonstrate IBM Cloud Object Storage Container Mode.<br>
        <br>Set your IBM COS parameters in the global_settings.py file!<br> 
        <br><br>Original Author: Patrik Jelinko (pjelinko@au1.ibm.com)
        <br>Enhancements: John Shubeck (jshubeck@us.ibm.com)""" + my_portal.html_end()


@app.route('/account_admin/account_list')
def account_list():
    command = 'GET {}:{}/accounts'.format(ENDPOINT, SERVICE_PORT)
    response_code, response_json = storage_account.list_storage_accounts()
    return my_portal.html_start("List of storage accounts (tenants)") \
        + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
        + my_portal.account_admin_link + my_portal.html_end()


@app.route('/account_admin/account_create', methods=['GET', 'POST'])
def account_create():
    if request.method == 'GET':
        return render_template('account_create_enhanced.html',
                               html_start=my_portal.html_start("Create New Storage Account"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        account_data = {}
        account_name = request.form['account']
        if request.form['max_container'] != "":
            account_data['X-Account-Max-Container-Count'] = request.form['max_container']
        if request.form['metadata_key1'] != "":
            account_data['X-Account-Meta-' + request.form['metadata_key1']] = request.form['metadata_value1']
        if request.form['metadata_key2'] != "":
            account_data['X-Account-Meta-' + request.form['metadata_key2']] = request.form['metadata_value2']
        if request.form['system_metadata_key'] != "":
            account_data['X-Account-Sysmeta-' + request.form['system_metadata_key']] = \
                request.form['system_metadata_value']
        command = 'PUT {}:{}/accounts/{}<br>Header:<pre>{}</pre>'\
                  .format(ENDPOINT, SERVICE_PORT, account_name, json.dumps(account_data, indent=4))
        response_code, response_json = storage_account.account_creation(account_name, account_data)
        return my_portal.html_start("Account creation") \
            + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
            + my_portal.account_admin_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.account_admin_link + my_portal.html_end()


@app.route('/account_admin/account_delete', methods=['GET', 'POST'])
def account_delete():
    if request.method == 'GET':
        return render_template('account_name_enhanced.html', accounts=storage_account.get_list_of_storage_accounts(),
                               html_start=my_portal.html_start("Select Storage Account"),
                               storage_account_list=my_portal.build_drop_down_storage_account_list(),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        command = 'DELETE {}:{}/accounts/{}</h4></div>'.format(ENDPOINT, SERVICE_PORT, request.form['account'])
        response_code, response_json = storage_account.account_deletion(request.form['account'])
        return my_portal.html_start("Account deletion") \
            + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
            + my_portal.account_admin_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.account_admin_link + my_portal.html_end()


@app.route('/account_admin/account_modify', methods=['GET', 'POST'])
def account_modify():
    if request.method == 'GET':
        return render_template('account_name_enhanced.html', accounts=storage_account.get_list_of_storage_accounts(),
                               html_start=my_portal.html_start("Select Storage Account"),
                               storage_account_list=my_portal.build_drop_down_storage_account_list(),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        if request.form['account'] == "":
            return redirect(url_for('account_modify'))
        response_code, response_json = storage_account.account_retrieval(request.form['account'])
        if response_code == 200:
            return redirect(url_for('account_modify2', account=request.form['account']))
        else:
            lines = "Account not found.<br>"
            return my_portal.html_start("Account modification") + lines + my_portal.account_admin_link \
                + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.account_admin_link + my_portal.html_end()


@app.route('/account_admin/account_modify2/<account>', methods=['GET', 'POST'])
def account_modify2(account):
    if request.method == 'GET':
        account_data = {}
        response_code, response_json = storage_account.account_retrieval(account)
        if response_code == 200:
            max_container_count_lines = """<tr><td>(Optional) Max container count:</td><td><input type="number" 
                                            name="max_container" /></td></tr>"""
            account_status_lines = ""  # not implemented
            meta_lines = []
            meta_lines_count = 0
            meta_lines.append("""<tr><td>(Optional) Custom metadata1 key:</td><td><input type="text" 
                name="metadata_key1" /></td><td>Metadata1 value:</td><td><input type="text" name="metadata_value1" />
                </td></tr>""")
            meta_lines.append("""<tr><td>(Optional) Custom metadata2 key:</td><td><input type="text" 
                name="metadata_key2" /></td><td>Metadata2 value:</td><td><input type="text" name="metadata_value2" />
                </td></tr>""")
            sysmeta_lines = """<tr><td>(Optional) Custom system metadata key:</td><td><input type="text" 
                name="system_metadata_key" /></td><td>Metadata value:</td><td><input type="text" 
                name="system_metadata_value" /></td></tr>"""
            for key in response_json.keys():
                if key == 'X-Account-Max-Container-Count':
                    account_data[key] = response_json[key]
                    max_container_count_lines = '<tr><td>(Optional) Max container count:</td><td>' \
                                                '<input type="number" name="max_container" value="' \
                                                + str(account_data[key]) + '"/></td></tr>'
                if key == 'X-Account-Status':
                    account_data[key] = response_json[key]
                if 'X-Account-Meta' in key:
                    account_data[key] = response_json[key]
                    if meta_lines_count == 0:
                        meta_lines[meta_lines_count] = \
                            '<tr><td>(Optional) Custom metadata1 key:</td><td><input type="text" ' \
                            'name="metadata_key1" value="' + key[15:] \
                            + '" /></td><td>Metadata1 value:</td><td>' \
                              '<input type="text" name="metadata_value1" value="' + account_data[key] + '" /></td></tr>'
                    elif meta_lines_count == 1:
                        meta_lines[meta_lines_count] = \
                            '<tr><td>(Optional) Custom metadata2 key:</td><td><input type="text" ' \
                            'name="metadata_key2" value="' + key[15:] \
                            + '" /></td><td>Metadata2 value:</td><td><input type="text" ' \
                              'name="metadata_value2" value="' + account_data[key] + '" /></td></tr>'
                    meta_lines_count += 1
                if 'X-Account-Sysmeta' in key:
                    account_data[key] = response_json[key]
                    sysmeta_lines = \
                        '<tr><td>(Optional) Custom system metadata key:</td><td>' \
                        '<input type="text" name="system_metadata_key" value="' + key[18:] \
                        + '" /></td><td>Metadata value:</td><td><input type="text" name="system_metadata_value" '\
                        'value="' + account_data[key] + '"/></td></tr>'
            return render_template('account_modify2_enhanced.html',
                                   html_start=my_portal.html_start("Modify Storage Account Details"),
                                   account=account,
                                   table_contents=max_container_count_lines + account_status_lines+meta_lines[0]
                                                  + meta_lines[1] + sysmeta_lines,
                                   back_to_account_admin=my_portal.account_admin_link,
                                   html_end=my_portal.html_end())
        else:
            lines = "Account not found.<br>"
            return my_portal.html_start("Account modification") + lines + my_portal.account_admin_link \
                + my_portal.html_end()
    elif request.method == 'POST':
        account_data = {}
        account_data['X-Account-Max-Container-Count'] = request.form['max_container']
        if request.form['metadata_key1'] != "":
            account_data['X-Account-Meta-' + request.form['metadata_key1']] = request.form['metadata_value1']
        if request.form['metadata_key2'] != "":
            account_data['X-Account-Meta-' + request.form['metadata_key2']] = request.form['metadata_value2']
        if request.form['system_metadata_key'] != "":
            account_data['X-Account-Sysmeta-' + request.form['system_metadata_key']] = \
                request.form['system_metadata_value']
        command = 'POST {}:{}/accounts/{}<br>Header:<br><pre>{}</pre>'\
                  .format(ENDPOINT, SERVICE_PORT, account, json.dumps(account_data, indent=4))

        response_code, response_json = storage_account.account_modification(account, account_data)
        return my_portal.html_start("Account modification") \
            + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
            + my_portal.account_admin_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.account_admin_link + my_portal.html_end()


@app.route('/account_admin/account_retrieval', methods=['GET', 'POST'])
def account_retrieval():
    if request.method == 'GET':
        return render_template('account_name_enhanced.html', accounts=storage_account.get_list_of_storage_accounts(),
                               html_start=my_portal.html_start("Select Storage Account"),
                               storage_account_list=my_portal.build_drop_down_storage_account_list(),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        account = request.form['account']
        command = 'HEAD {}:{}/accounts/{}'.format(ENDPOINT, SERVICE_PORT, account)
        response_code, response_json = storage_account.account_retrieval(account)
        return my_portal.html_start("Account retrieval for: " + account) \
            + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
            + my_portal.account_admin_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.account_admin_link + my_portal.html_end()


@app.route('/account_admin/specific_account_listing', methods=['GET', 'POST'])
def specific_account_listing():
    if request.method == 'GET':
        return render_template('account_name_enhanced.html', accounts=storage_account.get_list_of_storage_accounts(),
                               html_start=my_portal.html_start("Select Storage Account"),
                               storage_account_list=my_portal.build_drop_down_storage_account_list(),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        account = request.form['account']
        command = 'GET {}:{}/accounts/{}'.format(ENDPOINT, SERVICE_PORT, account)
        response_code, response_json = storage_account.specific_account_listing(account)
        return my_portal.html_start("Specific account listing for: " + account) \
            + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
            + my_portal.account_admin_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.account_admin_link + my_portal.html_end()


@app.route('/account_admin/account_list_containers', methods=['GET', 'POST'])
def account_list_containers():
    if request.method == 'GET':
        return render_template('account_name_enhanced.html', accounts=storage_account.get_list_of_storage_accounts(),
                               html_start=my_portal.html_start("Select Storage Account"),
                               storage_account_list=my_portal.build_drop_down_storage_account_list(),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        account = request.form['account']
        response_code, response_json = storage_account.list_containers_for_account2(account)
        command = 'GET {}:{}/accounts/{}/containers?limit={}'\
            .format(ENDPOINT, SERVICE_PORT, account, response_json.get('limit',
                                                                       storage_account.CONTAINER_LISTING_LIMIT))
        return my_portal.html_start("Container list for: " + account) \
            + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
            + my_portal.account_admin_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.account_admin_link + my_portal.html_end()


@app.route('/tenant_login', methods=['GET', 'POST'])
def tenant_login():
    login_link = '<div><a href="' + url_for('tenant_login') + '">Login again</a></div>'
    if request.method == 'GET':
        return render_template('tenant_login_enhanced.html', html_start=my_portal.html_start("Please Login"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        my_tenant.login(request.form['account'], request.form['password'])
        if my_tenant.get_login_status():
            return redirect(my_portal.url_for_tenant_actions)
        else:
            return my_portal.html_start("Login failed.") + login_link + my_portal.home_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.home_link + my_portal.html_end()


@app.route('/quick_login')
def quick_login():
    my_tenant.login(QUICK_LOGIN_STORAGE_ACCOUNT, "")
    my_tenant.set_active_credential(QUICK_LOGIN_ACCESS_KEY_ID)
    return redirect(my_portal.url_for_tenant_actions)


@app.route('/tenant_logout')
def tenant_logout():
    login_link = '<div><a href="' + url_for('tenant_login') + '">Login again</a></div>'
    my_tenant.logout()
    return my_portal.html_start("Logged out.") + login_link + my_portal.home_link + my_portal.html_end()


@app.route('/tenant/credentials_list')
def credentials_list():
    command = 'GET {}:{}/credentials/?project_id={}</h4></div>'.format(ENDPOINT, SERVICE_PORT, my_tenant.get_username())
    response_code, response_json = credentials.list_credentials(my_tenant.get_username())
    return my_portal.html_start("Credentials listing for " + my_tenant.get_username()) \
        + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
        + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/credential_create')
def credential_create():
    command_header = \
        """{
            "credential": {
                "project_id": """ + my_tenant.get_username() + """
                "type": "ec2"
            }
        }"""
    command = 'POST {}:{}/credentials/<br>Header:<pre>{}</pre>'.format(ENDPOINT, SERVICE_PORT, command_header)
    response_code, response_json = credentials.create_credential(my_tenant.get_username())
    if response_code == 201:
        my_tenant.load_credentials()
    return my_portal.html_start("Credentials listing for " + my_tenant.get_username()) \
        + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
        + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/credential_delete', methods=['GET', 'POST'])
def credential_delete():
    if request.method == 'GET':
        return render_template('credential_enhanced.html', access_keys=my_tenant.get_credentials_list(),
                               html_start=my_portal.html_start("Select Access Key ID"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        command = 'DELETE {}:{}/credentials/{}'.format(ENDPOINT, SERVICE_PORT, request.form['access_key_id'])
        response_code, response_json = credentials.delete_credential(my_tenant.get_username(),
                                                                     request.form['access_key_id'])
        if response_code == 204:
            my_tenant.load_credentials()
        return my_portal.html_start("Credential deletion") \
            + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
            + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/credential_show_details', methods=['GET', 'POST'])
def credential_show_details():
    if request.method == 'GET':
        return render_template('credential_enhanced.html', access_keys=my_tenant.get_credentials_list(),
                               html_start=my_portal.html_start("Select Access Key ID"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        command = 'GET {}:{}/credentials/{}'.format(ENDPOINT, SERVICE_PORT, request.form['access_key_id'])
        response_code, response_json = credentials.show_credential_details(my_tenant.get_username(),
                                                                           request.form['access_key_id'])
        return my_portal.html_start("Credential show details") \
            + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
            + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/update_credential_details', methods=['GET', 'POST'])
def update_credential_details():
    if request.method == 'GET':
        return render_template('credential_enhanced.html', access_keys=my_tenant.get_credentials_list(),
                               html_start=my_portal.html_start("Select Access Key ID"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        if credentials.find_credential(my_tenant.get_username(), request.form['access_key_id']):
            my_tenant.set_active_credential(request.form['access_key_id'])
            return redirect(url_for('update_credential_details2', access_key_id=request.form['access_key_id']))
        else:
            lines = "Credential not found.<br>"
            my_tenant.set_active_credential("")
            return my_portal.html_start("Credential update") + lines + my_portal.tenant_actions_link \
                + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/update_credential_details2/<access_key_id>', methods=['GET', 'POST'])
def update_credential_details2(access_key_id):
    if request.method == 'GET':
        response_code, response_json = credentials.show_credential_details(my_tenant.get_username(), access_key_id)
        if response_json['credential']['blob']['status'] == 'Active':
            active_checked = "checked"
            inactive_checked = ""
        else:
            active_checked = ""
            inactive_checked = "checked"
        if response_code == 200:
            return render_template('credential_update2_enhanced.html',
                                   html_start=my_portal.html_start("Modify Credential Details"),
                                   access_key_id=access_key_id,
                                   secret_key=response_json['credential']['blob']['secret'],
                                   active_checked=active_checked,
                                   inactive_checked=inactive_checked,
                                   back_to_tenant_actions=my_portal.tenant_actions_link,
                                   html_end=my_portal.html_end())
        else:
            lines = "Credential not found.<br>"
            return my_portal.html_start("Credential update") + lines + my_portal.tenant_actions_link \
                + my_portal.html_end()
    elif request.method == 'POST':
        response_code, response_json = credentials.update_credential(my_tenant.get_username(),
                                                                     my_tenant.get_active_credential(),
                                                                     status=request.form['status'],
                                                                     secret_key=request.form['secret_key'])
        if response_code == 200:
            command = 'PATCH {}:{}/credentials/{}<pre>{}</pre>' \
                      .format(ENDPOINT, SERVICE_PORT, my_tenant.get_active_credential(),
                              json.dumps(response_json['credential'], indent=4))
            return my_portal.html_start("Credential update") \
                + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
                + my_portal.tenant_actions_link + my_portal.html_end()
        else:
            command = 'PATCH {}:{}/credentials/{}'.format(ENDPOINT, SERVICE_PORT, my_tenant.get_active_credential())
            return my_portal.html_start("Credential update") \
                + my_portal.html_pretty_response(response_code, json.dumps(response_json, indent=4), command) \
                + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/select_credential', methods=['GET', 'POST'])
def select_credential():
    if request.method == 'GET':
        return render_template('credential_enhanced.html', access_keys=my_tenant.get_credentials_list(),
                               html_start=my_portal.html_start("Select Access Key ID"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        if credentials.find_credential(my_tenant.get_username(), request.form['access_key_id']):
            my_tenant.set_active_credential(request.form['access_key_id'])
            return redirect(my_portal.url_for_tenant_actions)
        else:
            my_tenant.set_active_credential("")
            lines = "Credential not found.<br>"
            return my_portal.html_start("Credential selection for bucket operations") + lines \
                + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/create_bucket', methods=['GET', 'POST'])
def create_bucket():
    if request.method == 'GET':
        return render_template('bucket_create_enhanced.html',
                               html_start=my_portal.html_start("Create Bucket"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        response_code, response_metadata = bucket.bucket_create(my_tenant.get_username(),
                                                                my_tenant.get_active_credential(),
                                                                request.form['bucket'])
        command = 's3 mb s3://' + request.form['bucket']
        return my_portal.html_start("Bucket creation") \
            + my_portal.html_pretty_response(response_code, json.dumps(response_metadata, indent=4, default=str),
                                             command) \
            + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/delete_bucket', methods=['GET', 'POST'])
def delete_bucket():
    if request.method == 'GET':
        response_code, response_metadata, buckets = bucket.bucket_list(my_tenant.get_username(),
                                                                       my_tenant.get_active_credential())
        if response_code == 200:
            bucket_list = [b['Name'] for b in buckets]
        else:
            bucket_list = []
        return render_template('bucket_enhanced.html', buckets=bucket_list,
                               html_start=my_portal.html_start("Select Bucket"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        response_code, response_metadata = bucket.bucket_delete(my_tenant.get_username(),
                                                                my_tenant.get_active_credential(),
                                                                request.form['bucket'])
        command = 's3 rb s3://' + request.form['bucket']
        return my_portal.html_start("Bucket deletion") \
            + my_portal.html_pretty_response(response_code, json.dumps(response_metadata, indent=4, default=str),
                                             command) \
            + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/list_buckets')
def list_buckets():
    command = 's3 ls s3://'
    response_code, response_metadata, buckets = bucket.bucket_list(my_tenant.get_username(),
                                                                   my_tenant.get_active_credential())
    if response_code == 200:
        # default=str to make json.dumps() work on the datetime object in the response
        bucket_formatted_list = json.dumps(buckets, indent=4, default=str)
        lines = my_portal.html_pretty_response(response_code, bucket_formatted_list, command,
                                               '<b>RESPONSE METADATA:</b> <pre> '
                                               + json.dumps(response_metadata, indent=4, default=str)) + '</pre>'
    else:
        lines = my_portal.html_pretty_response(response_code, json.dumps(response_metadata, indent=4, default=str),
                                               command)
    return my_portal.html_start("List of buckets for tenant: {} using Access Key ID: {}"
                                .format(my_tenant.get_username(), my_tenant.get_active_credential())) \
        + lines + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/get_bucket_acl', methods=['GET', 'POST'])
def get_bucket_acl():
    if request.method == 'GET':
        response_code, response_metadata, buckets = bucket.bucket_list(my_tenant.get_username(),
                                                                       my_tenant.get_active_credential())
        if response_code == 200:
            bucket_list = [b['Name'] for b in buckets]
        else:
            bucket_list = []
        return render_template('bucket_enhanced.html', buckets=bucket_list,
                               html_start=my_portal.html_start("Select Bucket"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        response_code, response_metadata, response = bucket.get_bucket_acl(my_tenant.get_username(),
                                                                           my_tenant.get_active_credential(),
                                                                           request.form['bucket'])
        del(response['ResponseMetadata'])
        command = 's3api get-bucket-acl --bucket ' + request.form['bucket']
        return my_portal.html_start("Get bucket ACL") \
            + my_portal.html_pretty_response(response_code, json.dumps(response, indent=4, default=str), command,
                                             '<b>RESPONSE METADATA:</b> <pre> '
                                             + json.dumps(response_metadata, indent=4, default=str) + '</pre>') \
            + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/put_bucket_canned_acl', methods=['GET', 'POST'])
def put_bucket_canned_acl():
    if request.method == 'GET':
        response_code, response_metadata, buckets = bucket.bucket_list(my_tenant.get_username(),
                                                                       my_tenant.get_active_credential())
        if response_code == 200:
            bucket_list = [b['Name'] for b in buckets]
        else:
            bucket_list = []
        return render_template('bucket_canned_acl_enhanced.html', buckets=bucket_list,
                               html_start=my_portal.html_start("Select Bucket and Canned ACL"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        response_code, response_metadata = bucket.put_bucket_canned_acl(my_tenant.get_username(),
                                                                        my_tenant.get_active_credential(),
                                                                        request.form['bucket'],
                                                                        request.form['new_acl'])
        command = 's3api put-bucket-acl --bucket ' + request.form['bucket'] + ' --acl ' + request.form['new_acl']
        return my_portal.html_start("Put bucket canned ACL") \
            + my_portal.html_pretty_response(response_code,
                                             json.dumps(response_metadata, indent=4, default=str), command) \
            + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/put_bucket_acl', methods=['GET', 'POST'])
def put_bucket_acl():
    if request.method == 'GET':
        response_code, response_metadata, buckets = bucket.bucket_list(my_tenant.get_username(),
                                                                       my_tenant.get_active_credential())
        if response_code == 200:
            bucket_list = [b['Name'] for b in buckets]
        else:
            bucket_list = []
        return render_template('bucket_enhanced.html', buckets=bucket_list,
                               html_start=my_portal.html_start("Select Bucket"),
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        if bucket.check_bucket(my_tenant.get_username(), my_tenant.get_active_credential(), request.form['bucket']):
            return redirect(url_for('put_bucket_acl2', bucket_name=request.form['bucket']))
        else:
            lines = "Bucket not found or bucket ACL cannot be retrieved.<br>"
            return my_portal.html_start("Bucket error") + lines + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()


@app.route('/tenant/put_bucket_acl2/<bucket_name>', methods=['GET', 'POST'])
def put_bucket_acl2(bucket_name):
    max_new_accounts = 3    # number of new accounts we can defined for new ACL, max 999999!

    if request.method == 'GET':
        current_acl = bucket.build_bucket_acl(my_tenant.get_username(), my_tenant.get_active_credential(), bucket_name)
        if not current_acl:     # if ACL is empty (which can't be unless there was an issue retrieving the ACL)
            return my_portal.html_start("Error retrieving bucket ACL") + my_portal.tenant_actions_link \
                   + my_portal.html_end()
        new_storage_accounts = []
        # Adding a blank row/item(s), to be able to add new storage account(s) to the ACL, these will be the first items
        for i in range(max_new_accounts):
            current_acl.insert(0, {'Grantee': '', 'DisplayGrantee': '', 'NONE': False, 'READ': False, 'WRITE': False,
                                   'READ_ACP': False, 'WRITE_ACP': False, 'FULL_CONTROL': False})
            new_storage_accounts.insert(i, '<select name="new_account' + str(i).zfill(6) +
                                           '">' + my_portal.build_drop_down_storage_account_list() + '</select>')
        # Building the table of the ACL with current permissions shown as default
        table_lines = '<tr><th>Grantee</th><th style="color:red;">NONE</th><th>READ</th><th>WRITE</th>' \
                      '<th>READ_ACP</th><th>WRITE_ACP</th><th>FULL_CONTROL</th></tr>'
        for index, item in enumerate(current_acl):
            if item['DisplayGrantee'] == 'Public (everyone)':
                table_lines += '<tr><td><input type="text" name="public' + str(index).zfill(6) \
                               + item['DisplayGrantee'] + '" value="' + item['DisplayGrantee'] + '" readonly></td>'
                for p in bucket.PUBLIC_PERMISSIONS:
                    if item[p]:
                        table_lines += '<td><input type="checkbox" name="perm' + str(index).zfill(6) + str(p) \
                                       + '" checked></td>'
                    else:
                        table_lines += '<td><input type="checkbox" name="perm' + str(index).zfill(6) + str(p) \
                                       + '"></td>'
            elif item['DisplayGrantee'] == 'Authenticated Users':
                table_lines += '<tr><td><input type="text" name="authusers' + str(index).zfill(6) \
                               + item['DisplayGrantee'] + '" value="' + item['DisplayGrantee'] + '" readonly></td>'
                for p in bucket.AUTHENTICATED_USERS_PERMISSIONS:
                    if item[p]:
                        table_lines += '<td><input type="checkbox" name="perm' + str(index).zfill(6) + str(p) \
                                       + '" checked></td>'
                    else:
                        table_lines += '<td><input type="checkbox" name="perm' + str(index).zfill(6) + str(p) \
                                       + '"></td>'
            else:
                if item['DisplayGrantee'] == '':    # New account, which is not in the current ACL
                    table_lines += '<tr><td>' + new_storage_accounts[index] + '</td>'
                else:   # Account is in the current ACL
                    table_lines += '<tr><td><input type="text" name="account' + str(index).zfill(6) \
                               + item['DisplayGrantee'] + '" value="' + item['DisplayGrantee'] + '" readonly></td>'
                for p in bucket.ACCOUNT_PERMISSIONS:
                    if item[p]:
                        table_lines += '<td><input type="checkbox" name="perm' + str(index).zfill(6) + str(p) \
                                       + '" checked></td>'
                    else:
                        table_lines += '<td><input type="checkbox" name="perm' + str(index).zfill(6) + str(p) \
                                       + '"></td>'
            table_lines += "</tr>"
        return render_template('bucket_acl2_enhanced.html',
                               html_start=my_portal.html_start("Modify Bucket ACL"),
                               bucket_name=bucket_name,
                               table_lines=table_lines,
                               back_to_tenant_actions=my_portal.tenant_actions_link,
                               html_end=my_portal.html_end())
    elif request.method == 'POST':
        new_acl = bucket.create_new_bucket_acl(my_tenant.get_username(), my_tenant.get_active_credential(), bucket_name,
                                               request.form.to_dict())
        response_code, response_metadata = bucket.put_bucket_acl(my_tenant.get_username(),
                                                                 my_tenant.get_active_credential(),
                                                                 bucket_name, new_acl)
        command = 's3api put-bucket-acl ---bucket {} --access-control-policy <pre>{}</pre>'\
            .format(bucket_name, json.dumps(new_acl, indent=4))
        return my_portal.html_start("Put bucket ACL") \
            + my_portal.html_pretty_response(response_code, json.dumps(response_metadata, indent=4), command) \
            + my_portal.tenant_actions_link + my_portal.html_end()
    else:
        return my_portal.html_start("Invalid request") + my_portal.tenant_actions_link + my_portal.html_end()
