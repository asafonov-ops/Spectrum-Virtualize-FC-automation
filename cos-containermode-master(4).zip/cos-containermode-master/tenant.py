# The tenant object stores the login information for the actual tenant (storage account) using the tenant actions pages
# 3rd party authentication (e.g. LDAP) could be implemented here

from storage_account import authenticate_storage_account
from credentials import list_credentials


class Tenant:
    def __init__(self):
        self.__logged_in = False
        self.__username = ""
        self.__password = ""
        self.__active_credential = ""
        self.__credentials = []

    def login(self, username, password):
        if authenticate_storage_account(username, password):
            self.__username = username
            self.__password = password
            self.__logged_in = True
            self.__active_credential = ""
            self.load_credentials()
            return True
        else:
            return False

    def load_credentials(self):
        response_code, response_json = list_credentials(self.__username)
        if response_code == 200:
            self.__credentials = []
            if 'credentials' in response_json:
                for credential in response_json['credentials']:
                    self.__credentials.append(credential['blob']['access'])
            return True
        else:
            return False

    def get_credentials_list(self):
        return self.__credentials

    def get_login_status(self):
        return self.__logged_in

    def get_active_credential(self):
        return self.__active_credential

    def set_active_credential(self, credential):
        self.__active_credential = credential

    def get_username(self):
        return self.__username

    def logout(self):
        self.__username = ""
        self.__password = ""
        self.__logged_in = False
        self.__active_credential = ""
        self.__credentials = []
