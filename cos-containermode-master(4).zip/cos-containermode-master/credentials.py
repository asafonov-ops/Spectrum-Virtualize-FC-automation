# Functions for all credential (access key ID/secret key) operations
# Individual functions can be tested if this file is run, uncomment lines at the bottom

import requests
from global_settings import *


def list_credentials(account):
    """ Returns a list of credentials for a specific storage accounts """

    uri = "%s:%s/%s%s" % (ENDPOINT, SERVICE_PORT, "credentials/?project_id=", account)

    response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                            verify=VERIFY_SSL_CERT_VALIDITY)
    return response.status_code, response.json()


def find_credential(account, access_key_id):
    """ Returns True if Access Key ID belongs to the specific storage accounts """

    uri = "%s:%s/%s%s" % (ENDPOINT, SERVICE_PORT, "credentials/?project_id=", account)

    response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                            verify=VERIFY_SSL_CERT_VALIDITY)
    if 'credentials' in response.json():
        for credential in response.json()['credentials']:
            if credential['blob']['access'] == access_key_id:
                return True
    return False


def get_secret_key(account, access_key_id):
    """ Returns the secret key if Access Key ID belongs to the specific storage accounts """

    uri = "%s:%s/%s%s" % (ENDPOINT, SERVICE_PORT, "credentials/?project_id=", account)

    response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                            verify=VERIFY_SSL_CERT_VALIDITY)
    if 'credentials' in response.json():
        for credential in response.json()['credentials']:
            if credential['blob']['access'] == access_key_id:
                return credential['blob']['secret']
    return None


def create_credential(account):
    """ Creates new credentials (access key ID, secret access key pair) for a specific storage accounts """

    uri = "%s:%s/%s" % (ENDPOINT, SERVICE_PORT, "credentials")
    json_request = {
        "credential": {
            "project_id": account,
            "type": "ec2"
        }
    }
    response = requests.post(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                             json=json_request, verify=VERIFY_SSL_CERT_VALIDITY)
    return response.status_code, response.json()


def delete_credential(account, access_key_id):
    """ Deletes a credential for a specific storage accounts """

    uri = "%s:%s/%s/%s" % (ENDPOINT, SERVICE_PORT, "credentials", access_key_id)

    if find_credential(account, access_key_id) or SKIP_TENANT_CREDENTIAL_CHECK:
        response = requests.delete(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                                   verify=VERIFY_SSL_CERT_VALIDITY)
        if response.status_code == 204:
            return response.status_code, {}
        else:
            return response.status_code, response.json()
    else:
        return 999, {"Error": "Access Key ID not found for the storage account. "
                              "(This is a custom response, not the actual response for the REST API command above. "
                              "To change the behaviour, please modify global_settings.py.)"}


def show_credential_details(account, access_key_id):
    """ Returns credential details for a specific credential/storage accounts """

    uri = "%s:%s/%s/%s" % (ENDPOINT, SERVICE_PORT, "credentials", access_key_id)

    if find_credential(account, access_key_id) or SKIP_TENANT_CREDENTIAL_CHECK:
        response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                                verify=VERIFY_SSL_CERT_VALIDITY)
        return response.status_code, response.json()
    else:
        return 999, {"Error": "Access Key ID not found for the storage account. "
                              "(This is a custom response, not the actual response for the REST API command. "
                              "To change the behaviour, please modify global_settings.py.)"}


def update_credential(account, access_key_id, **kwargs):
    """ Update credential details for a specific credential/storage accounts (active/inactive, new secret key) """

    uri = "%s:%s/%s/%s" % (ENDPOINT, SERVICE_PORT, "credentials", access_key_id)

    if find_credential(account, access_key_id) or SKIP_TENANT_CREDENTIAL_CHECK:
        response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                                verify=VERIFY_SSL_CERT_VALIDITY)
        if response.status_code == 200:
            credential = response.json()
            if 'status' in kwargs:
                credential['credential']['blob']['status'] = kwargs['status']
            if 'secret_key'in kwargs:
                credential['credential']['blob']['secret'] = kwargs['secret_key']
            response = requests.patch(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                                      json=credential, verify=VERIFY_SSL_CERT_VALIDITY)
        return response.status_code, response.json()
    else:
        return 999, {"Error": "Access Key ID not found for the storage account. "
                              "(This is a custom response, not the actual response for the REST API command."
                              "To change the behaviour, please modify global_settings.py.)"}


if __name__ == "__main__":
    # x = list_credentials("StorageAccount0")
    print(list_credentials("StorageAccount0"))
    # print(create_credential("StorageAccount0"))
    # print(delete_credential("StorageAccount0", 'YMyIrGJyZoZ2yIvtdcwO'))
    # print(show_credential_details("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW'))
    # print(update_credential("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', status='Active',
    #                         secret_key='abscdcccccccccccccccc'))
    # print(get_secret_key("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW'))

    pass
