# cos-containermode
_Simple portal to demonsrate IBM COS Container Mode features_

Starts a simple web portal on localhost, which demonstrates Storage Account creation/deletion/listing/etc.
Also let's you login as a tenant (e.g. with a storage account), and create/delete containers(buckets) and access keys.

This project is work in progress, but all REST API calls work now.

To install/run:
- Download the files from github either via the 'Download' link or ```git clone https://github.ibm.com/pjelinko/cos-containermode.git```
- If you have downloaded the package, unpack the zip file
- Change to the current directory to the scripts' location
- Install all Python module pre-requisites: ```pip3 install -r requirements.txt```
- Edit _global_settings.py_ (endpoint: Accesser hostname/IP, service account credentials)
- Run script: ```python3 app.py``` 
- Point your browser to: http://localhost (Webserver will be started on localhost:80, unless you have changed app.py)

Requirements:
- IBM COS 3.9+, Container Mode configured
- Python 3.5+ and following modules:
- Flask 
- Boto3 for bucket/container operations
- Requests 

Send question to: Patrik Jelinko - [pjelinko@au1.ibm.com](mailto:pjelinko@au1.ibm.com)
