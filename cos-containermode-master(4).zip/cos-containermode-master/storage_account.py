# Functions for all storage account (tenant) operations
# Individual functions can be tested if this file is run, uncomment lines at the bottom


import requests
import json
from global_settings import *


CONTAINER_LISTING_LIMIT = 1000    # default API limit of response size for listing containers


def get_list_of_storage_accounts():
    """ Returns a (Python) list of storage accounts """

    response_code, response_json = list_storage_accounts()
    if response_code == 200:
        if 'accounts' in response_json:
            return [a['id'] for a in response_json['accounts']]
        else:
            return []
    else:
        return []


def list_storage_accounts():
    """ Returns the 'list' of storage accounts in json format """

    uri = "%s:%s/%s" % (ENDPOINT, SERVICE_PORT, "accounts")

    header = {
        # "X-Trans-Id-Extra": "",   # For debugging
    }
    response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                            headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
    return response.status_code, response.json()


def find_storage_account(account_id):
    """ Returns True if storage account exists """

    uri = "%s:%s/%s" % (ENDPOINT, SERVICE_PORT, "accounts")

    header = {
        # "X-Trans-Id-Extra": "",   # For debugging
    }
    response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                            headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
    if response.status_code == 200:
        a = json.loads(response.text)
        for account in a['accounts']:
            if account['id'] == account_id:
                return True
    return False


def authenticate_storage_account(account_id, password):
    """ Returns True if storage account is authenticated by an external service (not implemented)
    Currently we are just checking if the account exists """

    if find_storage_account(account_id):
        """ We don't have an external authentication service, but e.g. LDAP authentication to be implemented here. 
        For now function return True if Storage Account exists regardless of the password. """
        return True
    else:
        return False


def account_creation(name, account_data):
    """ Creates a new storage account """

    uri = "%s:%s/%s/%s" % (ENDPOINT, SERVICE_PORT, "accounts", name)

    header = {
        # "X-Trans-Id-Extra": "",   # For debugging
    }
    header = {
        **header,
        **account_data
    }
    response = requests.put(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                            headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
    return response.status_code, response.json()


def account_modification(name, account_data):
    """ Creates a new storage account """

    uri = "%s:%s/%s/%s" % (ENDPOINT, SERVICE_PORT, "accounts", name)

    header = {
        # "X-Trans-Id-Extra": "",   # For debugging
    }
    header = {
        **header,
        **account_data
    }
    response = requests.post(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                             headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
    return response.status_code, response.json()


def account_deletion(name):
    """ Deletes an existing storage account """

    uri = "%s:%s/%s/%s" % (ENDPOINT, SERVICE_PORT, "accounts", name)

    header = {
        # "X-Trans-Id-Extra": "",   # For debugging
    }
    response = requests.delete(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                               headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
    if response.text == "":
        resp = {}
    else:
        resp = response.json()
    return response.status_code, resp


def account_retrieval(account_id):
    """ The account retrieval request returns the current configuration for a specific storage account. """

    if account_id == '':
        return 996, {"Error": "Storage Account not specified."}
    uri = "%s:%s/%s/%s" % (ENDPOINT, SERVICE_PORT, "accounts", account_id)
    header = {
        # "X-Trans-Id-Extra": "",   # For debugging
    }
    response = requests.head(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                             headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
    return response.status_code, dict(response.headers)


def specific_account_listing(account_id):
    """ The specific account listing request returns the storage usage for a specific storage account. """

    if account_id == '':
        return 996, {"Error": "Storage Account not specified."}
    uri = "%s:%s/%s/%s" % (ENDPOINT, SERVICE_PORT, "accounts", account_id)
    header = {
        # "X-Trans-Id-Extra": "",   # For debugging
    }
    response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                            headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
    if response.text == "":
        resp = {}
    else:
        resp = response.json()
    return response.status_code, resp


def list_containers_for_account(account):
    """ The following API provides an interface intended to be used by a Service User for generically listing
    containers and buckets under a storage account. Limited to 1000 containers in the response.
    The portal is now using the list_containers_for_account2() which overcomes the limit. This version is kept for
    reference only. """

    uri = "%s:%s/%s/%s/%s" % (ENDPOINT, SERVICE_PORT, "accounts", account, "containers")
    header = {
        # "X-Trans-Id-Extra": "",   # For debugging
    }
    response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                            headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
    return response.status_code, response.json()


def list_containers_for_account2(account):
    """ The following API provides an interface intended to be used by a Service User for generically listing
    containers and buckets under a storage account. First checks how many containers the account has and adjusts the
    limit in the query accordingly to avoid a truncated response. Default API limit is 1000 """

    response_code, response_json = specific_account_listing(account)
    if response_code == 200:
        max_results = max(response_json['account']['container_count'], CONTAINER_LISTING_LIMIT)
        uri = "%s:%s/%s/%s/%s?limit=%s" % (ENDPOINT, SERVICE_PORT, "accounts", account, "containers", max_results)
        header = {
            # "X-Trans-Id-Extra": "",   # For debugging
        }
        response = requests.get(url=uri, auth=(SERVICE_ACCOUNT, SERVICE_ACCOUNT_PASSWORD),
                                headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
        return response.status_code, response.json()
    else:
        return response_code, response_json


if __name__ == "__main__":
    # print(list_storage_accounts())
    # print(account_retrieval("StorageAccount0"))
    # print(list_containers_for_account("StorageAccount0"))
    # print(specific_account_listing("StorageAccount0"))
    # print(account_creation("TestAcc0", {}))
    # print(account_retrieval("user1"))
    #print(account_modification("user1", {'X-Account-Max-Container-Count': '20'}))
    # print(account_deletion("TestAcc0"))
    # print(find_storage_account("StorageAccount0"))
    print(list_containers_for_account2("StorageAccount0"))

    pass
