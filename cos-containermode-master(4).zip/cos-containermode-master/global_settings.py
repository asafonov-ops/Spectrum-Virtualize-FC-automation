# Global constants, variables

ENDPOINT = "http://10.2.20.229"     # set IP or hostname of Accesser, if HTTPS is used set SECURE to True
SECURE = False       # Use SSL for boto3 calls for bucket operations
SERVICE_PORT = "8337"  # Container mode service port, default: 8337 for HTTP, 8338 for HTTPS
CONTAINER_VAULT = "ContainerVault0"
# by default provisioning code is the same as the container vault's name, but check your vault settings in the Manager
# GUI, otherwise if you set it incorrectly, container creation will fail with InvalidLocationConstraint error
PROVISIONING_CODE = "ContainerVault0"
SERVICE_ACCOUNT = "sa0"     # container mode service account, get details from COS Manager
SERVICE_ACCOUNT_PASSWORD = "P@ssw0rd"
VERIFY_SSL_CERT_VALIDITY = False

QUICK_LOGIN_ENABLED = True  # to speed up the tenant login procedure (e.g. for testing); set to False to disable
QUICK_LOGIN_STORAGE_ACCOUNT = "StorageAccount0"
QUICK_LOGIN_ACCESS_KEY_ID = "FUcU4tgtNWUXsre2lXcW"

# If set to True the portal will not check if the credential you are trying to work with actually belongs to the
# tenant (storage account) logged in. This will result that e.g. tenant X will be able delete tenant Y's credentials,
# BUT portal will actually show the real REST API responses of certain operations (e.g. credentials delete/update), and
# not display an error message if credential doesn't belong to the actual tenant
SKIP_TENANT_CREDENTIAL_CHECK = True

# Branding options
HTML_CSS = "/static/css/dark.css"      # specify css file, current options: dark.css or light.css
LOGO = "/static/pic/ibm_logo.png"      # specify the logo you want to use (jpg or png), will be scaled to 40px height, default: ibm_logo.png
PORTAL_NAME = "Service Provider Interface Prototype"    # Name of the portal (top right hand corner)
