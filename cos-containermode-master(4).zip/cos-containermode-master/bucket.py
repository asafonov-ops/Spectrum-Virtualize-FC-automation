# Functions for all bucket/container operations by using AWS Boto3 library
# Individual functions can be tested if this file is run, uncomment lines at the bottom


import boto3
from global_settings import *
from credentials import get_secret_key
# import requests    for alternative version of put_bucket, not used for now
# from requests_aws4auth import AWS4Auth    # for alternative version of put_bucket, not used for now
import json     # for testing the functions


ACCOUNT_PERMISSIONS = ['NONE', 'READ', 'WRITE', 'READ_ACP', 'WRITE_ACP', 'FULL_CONTROL']
PUBLIC_PERMISSIONS = ['NONE', 'READ', 'WRITE']
AUTHENTICATED_USERS_PERMISSIONS = ['NONE', 'READ']


def bucket_list(account, access_key_id):
    """ Returns a 'list' of buckets for a specific storage account using a specific access key """

    secret_key = get_secret_key(account, access_key_id)
    if secret_key is not None:
        s3_client = boto3.client('s3', aws_access_key_id=access_key_id, aws_secret_access_key=secret_key,
                                 endpoint_url=ENDPOINT, use_ssl=SECURE)
        try:
            response = s3_client.list_buckets()
        except Exception as ex:
            return 997, {"Error": "An exception of type {0} occurred during the S3 API call. "
                                  "Arguments: {1!r}".format(type(ex).__name__, ex.args)}, []
        return response['ResponseMetadata']['HTTPStatusCode'], response['ResponseMetadata'], response['Buckets']
    else:
        return 998, {"Error": "Access Key ID/Secret Key pair ({}/{}) not valid".format(access_key_id, secret_key)}, []


def bucket_create(account, access_key_id, bucket):
    """ Creates a new bucket for a specific storage account using a specific access key """

    secret_key = get_secret_key(account, access_key_id)
    if secret_key is not None:
        s3_client = boto3.client('s3', aws_access_key_id=access_key_id, aws_secret_access_key=secret_key,
                                 endpoint_url=ENDPOINT, use_ssl=SECURE)
        try:
            response = s3_client.create_bucket(Bucket=bucket,
                                               CreateBucketConfiguration={'LocationConstraint': PROVISIONING_CODE})
        except Exception as ex:
            return 997, {"Error": "An exception of type {0} occurred during the S3 API call. "
                                  "Arguments: {1!r}".format(type(ex).__name__, ex.args)}
        return response['ResponseMetadata']['HTTPStatusCode'], response['ResponseMetadata']
    else:
        return 998, {"Error": "Access Key ID/Secret Key pair ({}/{}) not valid".format(access_key_id, secret_key)}


def bucket_delete(account, access_key_id, bucket):
    """ Deletes a bucket for a specific storage account using a specific access key """

    secret_key = get_secret_key(account, access_key_id)
    if secret_key is not None:
        s3_client = boto3.client('s3', aws_access_key_id=access_key_id, aws_secret_access_key=secret_key,
                                 endpoint_url=ENDPOINT, use_ssl=SECURE)
        try:
            response = s3_client.delete_bucket(Bucket=bucket)
        except Exception as ex:
            return 997, {"Error": "An exception of type {0} occurred during the S3 API call. "
                                  "Arguments: {1!r}".format(type(ex).__name__, ex.args)}
        return response['ResponseMetadata']['HTTPStatusCode'], response['ResponseMetadata']
    else:
        return 998, {"Error": "Access Key ID/Secret Key pair ({}/{}) not valid".format(access_key_id, secret_key)}


def get_bucket_acl(account, access_key_id, bucket):
    """ Returns the ACL for a specific bucket """

    secret_key = get_secret_key(account, access_key_id)
    if secret_key is not None:
        s3_client = boto3.client('s3', aws_access_key_id=access_key_id, aws_secret_access_key=secret_key,
                                 endpoint_url=ENDPOINT, use_ssl=SECURE)
        try:
            response = s3_client.get_bucket_acl(Bucket=bucket)
        except Exception as ex:
            return 997, {"Error": "An exception of type {0} occurred during the S3 API call. "
                                  "Arguments: {1!r}".format(type(ex).__name__, ex.args)}, {}
        return response['ResponseMetadata']['HTTPStatusCode'], response['ResponseMetadata'], response
    else:
        return 998, {"Error": "Access Key ID/Secret Key pair ({}/{}) not valid".format(access_key_id, secret_key)}, {}


def put_bucket_canned_acl(account, access_key_id, bucket, new_acl):
    """ Sets the ACL for a specific bucket, only canned ACLs supported: private|public-read|public-read-write|
    authenticated-read. Warning: this will overwrite all permissions with the exception of the owner's full control.
    Reference: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3.html#bucketacl """

    secret_key = get_secret_key(account, access_key_id)
    if secret_key is not None:
        s3_resource = boto3.resource('s3', aws_access_key_id=access_key_id, aws_secret_access_key=secret_key,
                                     endpoint_url=ENDPOINT, use_ssl=SECURE)
        try:
            bucket_acl = s3_resource.BucketAcl(bucket)
            response = bucket_acl.put(ACL=new_acl)
        except Exception as ex:
            return 997, {"Error": "An exception of type {0} occurred during the S3 API call. "
                                  "Arguments: {1!r}".format(type(ex).__name__, ex.args)}
        return response['ResponseMetadata']['HTTPStatusCode'], response['ResponseMetadata']
    else:
        return 998, {"Error": "Access Key ID/Secret Key pair ({}/{}) not valid".format(access_key_id, secret_key)}


# def put_bucket_canned_acl2(account, access_key_id, bucket, new_acl):
#     """ Sets the ACL for a specific bucket, only canned ACLs supported: private|public-read|public-read-write|
#     authenticated-read. This method is using a put request with the appropriate header.
#     NOT USED for the current version of the code """
#     secret_key = get_secret_key(account, access_key_id)
#     if secret_key is not None:
#         uri = "%s/%s?acl" % (ENDPOINT, bucket)
#         header = {
#             "x-amz-acl": new_acl,
#         }
#         response = requests.put(url=uri, auth=AWS4Auth(access_key_id, secret_key, "", "s3"),
#                                 headers=header, verify=VERIFY_SSL_CERT_VALIDITY)
#
#         return response.status_code, response.text, dict(response.headers)
#     else:
#         return 998, {"Error": "Access Key ID/Secret Key pair ({}/{}) not valid".format(access_key_id, secret_key)}


def put_bucket_acl(account, access_key_id, bucket, new_acl):
    """ Sets the ACL for a specific bucket using using AccessControlPolicy JSON parameter
    Reference: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3.html#bucketacl """

    secret_key = get_secret_key(account, access_key_id)
    if secret_key is not None:
        s3_resource = boto3.resource('s3', aws_access_key_id=access_key_id, aws_secret_access_key=secret_key,
                                     endpoint_url=ENDPOINT, use_ssl=SECURE)
        try:
            bucket_acl = s3_resource.BucketAcl(bucket)
            response = bucket_acl.put(AccessControlPolicy=new_acl)
        except Exception as ex:
                return 997, {"Error": "An exception of type {0} occurred during the S3 API call. "
                             "Arguments: {1!r}".format(type(ex).__name__, ex.args)}
        return response['ResponseMetadata']['HTTPStatusCode'], response['ResponseMetadata']
    else:
        return 998, {"Error": "Access Key ID/Secret Key pair ({}/{}) not valid".format(access_key_id, secret_key)}


def check_bucket(account, access_key_id, bucket):
    """ A get_bucket_acl request is generated to check if the bucket exists and we have access to its ACL
    at all. Returns True if all good """

    secret_key = get_secret_key(account, access_key_id)
    if secret_key is not None:
        s3_client = boto3.client('s3', aws_access_key_id=access_key_id, aws_secret_access_key=secret_key,
                                 endpoint_url=ENDPOINT, use_ssl=SECURE)
        try:
            response = s3_client.get_bucket_acl(Bucket=bucket)
        except Exception as ex:
            return False
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            return True
        else:
            return False
    else:
        return False


def simplify_grantee(grantee):
    """ Grantee value can be long, complex to understand, we 'try to' create a simplified version to display it on
    the portal in a table where space is limited
    NOTE: Only AllUsers, AuthenticatedUsers and CanonicalUser types will work properly if a put_bucket_acl is called """

    if grantee['Type'] == 'Group':
        if 'URI' in grantee:
            if grantee['URI'] == 'http://acs.amazonaws.com/groups/global/AllUsers':
                simple_grantee = 'Public (everyone)'
            elif grantee['URI'] == 'http://acs.amazonaws.com/groups/global/AuthenticatedUsers':
                simple_grantee = 'Authenticated Users'
            else:
                simple_grantee = grantee['URI']
        else:
            simple_grantee = str(grantee)
    elif grantee['Type'] == 'CanonicalUser':
        if 'DisplayName' in grantee:
            simple_grantee = grantee['DisplayName']
        else:
            simple_grantee = grantee['ID']
    else:
        simple_grantee = str(grantee)

    return simple_grantee


def generate_grantee(**kwargs):
    """ From the simplified Grantee value generates the Grantee which needed for the put_bucket_acl request
    NOTE: Only AllUsers, AuthenticatedUsers and CanonicalUser types will work properly if a put_bucket_acl is called """

    if 'id' in kwargs:
        return {
            "DisplayName": kwargs['id'],
            "ID": kwargs['id'],
            "Type": "CanonicalUser"
        }
    if 'group' in kwargs:
        if kwargs['group'] == 'public':
            return {
                "URI": 'http://acs.amazonaws.com/groups/global/AllUsers',
                "Type": "Group"
            }
        elif kwargs['group'] == 'authusers':
            return {
                "URI": 'http://acs.amazonaws.com/groups/global/AuthenticatedUsers',
                "Type": "Group"
            }
    return {}


def build_bucket_acl(account, access_key_id, bucket):
    """ Builds a fully defined list of ACL for a specific bucket to be easily displayed in an HTML form.
    Public (everyone) and Authenticated Users access is added to the end of the ACL for completeness """

    response_code, response_metadata, response = get_bucket_acl(account, access_key_id, bucket)
    if response_code == 200:
        acl = []
        public_acl_index = -1
        authenticated_users_acl_index = -1
        for i in response['Grants']:    # Looping through permissions to generate ACL list needed for HTML display
            found = False
            for j in range(len(acl)):
                if acl[j]['Grantee'] == i['Grantee']:   # If Grantee is in the list, then just changes the permission
                    found = True
                    acl[j][i['Permission']] = True
                    break
            if not found:   # If Grantee is new, adds it to the list with fully defined permission list
                acl.append({'Grantee': i['Grantee'], i['Permission']: True})
                for p in ['NONE', 'READ', 'WRITE', 'READ_ACP', 'WRITE_ACP', 'FULL_CONTROL']:
                    if p not in acl[-1]:
                        acl[-1][p] = False
                # We make the Grantee field simpler for display
                acl[-1]['DisplayGrantee'] = simplify_grantee(i['Grantee'])
                if acl[-1]['DisplayGrantee'] == 'Public (everyone)':
                    public_acl_index = len(acl) - 1
                if acl[-1]['DisplayGrantee'] == 'Authenticated Users':
                    authenticated_users_acl_index = len(acl) - 1

        if public_acl_index == -1:  # if there was no public access control entry, adds it to the end of the ACL
            acl.append({'Grantee': {}, 'DisplayGrantee': 'Public (everyone)', 'NONE': True, 'READ': False,
                        'WRITE': False})
        else:   # otherwise moves it to the end of the list to look nice
            acl.append(acl.pop(public_acl_index))
        if authenticated_users_acl_index == -1:     # if there was no Authenticated Users entry, adds it
            acl.append({'Grantee': {}, 'DisplayGrantee': 'Authenticated Users', 'NONE': True, 'READ': False})
        else:   # otherwise moves it to the end of the list to look nice
            acl.append(acl.pop(authenticated_users_acl_index))
        return acl
    else:
        return []


def validate_acl(acl):
    """ Removes other permissions if NONE was selected, and removes unnecessary NONE permissions to make the
    ACL compliant with the put_bucket_acl request """

    to_delete = []
    for grant in acl['Grants']:
        if grant['Permission'] == 'NONE':
            to_delete.append(grant['Grantee'])
    for i in range(len(acl['Grants'])-1, 0, -1):
        if acl['Grants'][i]['Grantee'] in to_delete:
            del acl['Grants'][i]
    return acl


def create_new_bucket_acl(account, access_key_id, bucket, form):
    """ Updates the current ACL with the changes prescribed by the HTML form, returns JSON which can be used buy
    put_bucket_acl() """

    code, metadata, response = get_bucket_acl(account, access_key_id, bucket)
    if code == 200:
        new_acl = {'Grants': [], 'Owner': response['Owner']}   # initilise new_acl with the existing Owner, empty grants
        form_keys = list(form.keys())     # creates a separate list to be able to pop out elements from form dict
        for key in form_keys:   # looping through the HTML form values to build the new ACL
            if key[:4] == 'perm':   # to speed up the loop
                pass
            if key[:6] == 'public':
                for i in ['perm' + key[6:12] + p for p in PUBLIC_PERMISSIONS]:
                    if form.pop(i, None) == 'on':
                        new_acl['Grants'].append({"Grantee": generate_grantee(group='public'), "Permission": i[10:]})
            if key[:9] == 'authusers':
                for i in ['perm' + key[9:15] + p for p in AUTHENTICATED_USERS_PERMISSIONS]:
                    if form.pop(i, None) == 'on':
                        new_acl['Grants'].append({"Grantee": generate_grantee(group='authusers'), "Permission": i[10:]})
            if key[:7] == 'account':
                for i in ['perm' + key[7:13] + p for p in ACCOUNT_PERMISSIONS]:
                    if form.pop(i, None) == 'on':
                        new_acl['Grants'].append({"Grantee": generate_grantee(id=key[13:]), "Permission": i[10:]})
            if key[:11] == 'new_account':
                for i in ['perm' + key[11:17] + p for p in ACCOUNT_PERMISSIONS]:
                    if form.pop(i, None) == 'on':
                        new_acl['Grants'].append({"Grantee": generate_grantee(id=form[key]), "Permission": i[10:]})
        return validate_acl(new_acl)
    else:
        return {}


if __name__ == "__main__":
    # Testing the different functions... Uncomment what's needed.

    #print(bucket_create("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket7"))
    #print(bucket_delete("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket2"))
    #print(bucket_list("StorageAccount0", 'TaomByigaKHAUG6AHAl5'))
    #print(get_bucket_acl("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket7"))
    #print(put_bucket_canned_acl("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket7", 'public-read-write'))
    #print(put_bucket_canned_acl2("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket7", 'public-read'))
    #print(get_bucket_acl("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket7"))

    #code, metadata, response = get_bucket_acl("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket7")
    #print(json.dumps(response, indent=4))
    #acl = {'Grants': response['Grants'], 'Owner': response['Owner']}
    #print(json.dumps(acl, indent=4))
    #acl['Grants'].append({
    #        "Grantee": {
    #            "DisplayName": "PA",
    #            "ID": "PA",
    #            "Type": "CanonicalUser"
    #        },
    #        "Permission": "WRITE_ACP"
    #    })
    #print(json.dumps(current_acl, indent=4))
    #print(put_bucket_acl("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket7", acl))

    #print(build_bucket_acl("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket7"))
    # print(find_bucket("StorageAccount0", 'FUcU4tgtNWUXsre2lXcW', "bucket7"))

    print(generate_grantee(id='User1'))
    print(generate_grantee(group='public'))

    pass
