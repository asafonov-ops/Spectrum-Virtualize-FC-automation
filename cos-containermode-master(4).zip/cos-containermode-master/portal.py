# definition of the portal class, which helps to generate HTML pages

from global_settings import LOGO, PORTAL_NAME, HTML_CSS
import storage_account


class Portal:
    def __init__(self):
        self.titlebar = ''
        self.url_for_home = ''
        self.home_link = ''
        self.url_for_account_admin = ''
        self.account_admin_link = ''
        self.url_for_tenant_actions = ''
        self.tenant_actions_link = ''
        self.url_for_about = ''
        self.navbar = ''
        self.__html_start = '<!DOCTYPE html> \
                            <html lang="en"> \
                            <head> \
                                <meta charset="UTF-8"> \
                                <link rel="stylesheet" type="text/css" href="' + HTML_CSS + '">'
        self.__html_end = '</body></html>'

    def init(self, home, account_admin, tenant_actions, about):
        self.url_for_home = home
        self.titlebar = \
            '<ul class="titlebar"> \
              <li class="titlebar_item"><img src="' + LOGO + '" alt="IBM" height=30></li> \
              <li class="titlebar_item" style="float:right"><a href="' + self.url_for_home + '">' + PORTAL_NAME + '</a></li> \
            </ul>'
        self.home_link = '<p><a href="' + self.url_for_home + '">Home</a></p>'
        self.url_for_account_admin = account_admin
        self.account_admin_link = '<p><a href="' + self.url_for_account_admin + '">Back to Account Admin</a></p>'
        self.url_for_tenant_actions = tenant_actions
        self.tenant_actions_link = '<p><a href="' + self.url_for_tenant_actions + '">Back to Tenant Actions</a></p>'
        self.url_for_about = about
        self.set_active_navbar_item('home')

    def set_active_navbar_item(self, active_item):
        """ Generates the navigation bar depending on which section is displayed """

        if active_item == 'account_admin':
            self.navbar = \
                '<ul class="navbar"> \
                  <li class="navbar_item"><a href="' + self.url_for_home + '">Home</a></li> \
                  <li class="navbar_item"><a class="active_navbar_item" href="' + self.url_for_account_admin + '">Account Admin</a></li> \
                  <li class="navbar_item"><a href="' + self.url_for_tenant_actions + '">Tenant Actions</a></li> \
                  <li class="navbar_item" style="float:right"><a href="' + self.url_for_about + '">About</a></li> \
                </ul>'
        elif active_item == 'tenant_actions':
            self.navbar = \
                '<ul class="navbar"> \
                  <li class="navbar_item"><a href="' + self.url_for_home + '">Home</a></li> \
                  <li class="navbar_item"><a href="' + self.url_for_account_admin + '">Account Admin</a></li> \
                  <li class="navbar_item"><a class="active_navbar_item" href="' + self.url_for_tenant_actions + '">Tenant Actions</a></li> \
                  <li class="navbar_item" style="float:right"><a href="' + self.url_for_about + '">About</a></li> \
                </ul>'
        elif active_item == 'about':
            self.navbar = \
                '<ul class="navbar"> \
                  <li class="navbar_item"><a href="' + self.url_for_home + '">Home</a></li> \
              <li class="navbar_item"><a href="' + self.url_for_account_admin + '">Account Admin</a></li> \
              <li class="navbar_item"><a href="' + self.url_for_tenant_actions + '">Tenant Actions</a></li> \
              <li class="navbar_item" style="float:right"><a class="active_navbar_item" href="' + self.url_for_about + '">About</a></li> \
            </ul>'
        else:
            self.navbar = \
                '<ul class="navbar"> \
                  <li class="navbar_item"><a class="active_navbar_item" href="' + self.url_for_home + '">Home</a></li> \
                  <li class="navbar_item"><a href="' + self.url_for_account_admin + '">Account Admin</a></li> \
                  <li class="navbar_item"><a href="' + self.url_for_tenant_actions + '">Tenant Actions</a></li> \
                  <li class="navbar_item" style="float:right"><a href="' + self.url_for_about + '">About</a></li> \
                </ul>'

    def html_start(self, title):
        """ Generates HTML code for first part of the pages including header and title """

        return self.__html_start + """
                    <title>{}</title> 
                </head> 
                <body>
                    {}
                    {}
                    <h2>{}</h2>""".format(title, self.titlebar, self.navbar, title)

    def html_end(self):
        """ Generates HTML code for first part of the pages including header and title """

        return self.__html_end

    @staticmethod
    def html_pretty_response(response_code, response_text, command, *argv):
        """ Generates the HTML code for the API responses in a pretty format. If response code is 2xx, then we consider
        it SUCCESS, and the response gets a green frame, otherwise FAILURE -> red frame """

        if 200 <= response_code <= 299:
            div_with_style = '<div style="padding: 10px; border: 1px solid green; margin: 5px; overflow: auto; ' \
                             'max-height: 500px;">'
            was_successful = div_with_style + '<b>RESPONSE CODE:</b> SUCCESS (' + str(response_code) + ')</div>'
        else:
            div_with_style = '<div style="padding: 10px; border: 1px solid red; margin: 5px; overflow: auto; ' \
                             'max-height: 500px;">'
            was_successful = div_with_style + '<b>RESPONSE CODE:</b> ERROR (' + str(response_code) + ')</div>'
        lines = div_with_style + '<b>REST API command:</b> ' + command + '</div>' + was_successful \
            + div_with_style + '<b>RESPONSE TEXT:</b><br><pre>' + response_text + '</pre></div>'
        # Additional arguments (e.g. response metadata) displayed in a separate frame
        for arg in argv:
            lines = lines + div_with_style + arg + '</div>'
        return lines

    @staticmethod
    def build_drop_down_storage_account_list():
        """ Builds the HTML code for a drop down menu of existing storage accounts plus dummy values for testing """

        select_list = '<option value="" selected>-</option>'
        for s in storage_account.get_list_of_storage_accounts():
            select_list += '<option value=' + s + '>' + s + '</option>'
        select_list += '<option value="dummy926482545">dummy926482545 - to test not found</option>' \
                       '<option value="dummy!">dummy! - to test invalid characters</option></select>'
        return select_list
