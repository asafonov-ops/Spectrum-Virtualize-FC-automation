# Run this file!
# Set endpoint, service account credentials in the global_settings.py file!

import sys
import flask
import tenant
import portal

# You need to have Python 3.5+ to run this app
if sys.version_info[0] < 3 or (sys.version_info[0] == 3 and sys.version_info[1] < 5):
    print("Please run this script with Python version 3.5+.")
    print("Your current Python version is: {}.{}".format(sys.version_info[0], sys.version_info[1]))
    sys.exit(1)

WEB_SERVER_PORT = 80    # web server runs on localhost, point your browser to: http://127.0.0.1[:port]
# The web server will run on localhost/127.0.0.1 by default, it is not accessible remotely.
# If you enable remote access, it will be available via your machine's IP address(es)
ENABLE_REMOTE_ACCESS = False
DEBUG = True
# Defining the tenant object which will be used for tenant related functions, e.g.: create buckets, credentials
my_tenant = tenant.Tenant()
# Defining the portal object which will be used for the HTML portal page generation
my_portal = portal.Portal()

app = flask.Flask(__name__)
wsgi_app = app.wsgi_app

from routes_enhanced import *

if __name__ == '__main__':
    if ENABLE_REMOTE_ACCESS:
        app.run(debug=DEBUG, port=WEB_SERVER_PORT, host='0.0.0.0')  # Starting web server on all IPs
    else:
        app.run(debug=DEBUG, port=WEB_SERVER_PORT)                  # Starting web server on localhost (127.0.0.1)
